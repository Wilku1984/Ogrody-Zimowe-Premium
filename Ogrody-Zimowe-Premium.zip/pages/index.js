export default function Home() {
  return (
    <div style={{ padding: '2rem', fontFamily: 'sans-serif' }}>
      <h1>Ogrody Zimowe Premium</h1>
      <p>Strona główna w wersji demo. Więcej już wkrótce!</p>
    </div>
  );
}